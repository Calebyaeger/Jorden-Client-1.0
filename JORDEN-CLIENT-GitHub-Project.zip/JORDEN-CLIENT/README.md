# JORDEN CLIENT 1.0.0

A Lunar-inspired, client-side Fabric utility and HUD mod for **Minecraft Java 1.21.11**.

## Included in this starter release

- Custom HUD with FPS, coordinates, keystrokes, CPS indicator, and armor status
- Toggle Sprint
- Zoom (hold `C`)
- Client module menu (Right Shift)
- Custom crosshair
- Theme selection and saved configuration
- Custom title-screen entry button
- GitHub Actions build that uploads the remapped Fabric `.jar`

This is an original client-side mod, not a modified Lunar Client. It does not include cheats, combat automation, or server-side changes.

## Build on GitHub

1. Create a new GitHub repository named `JORDEN-CLIENT`.
2. Upload **all files and folders** from this project into the repository's root.
3. Open the **Actions** tab. If prompted, enable GitHub Actions.
4. Open the workflow named **Build JORDEN CLIENT** and select **Run workflow** (or push a commit).
5. Wait for the green check mark.
6. Open the completed workflow run, scroll to **Artifacts**, and download `JORDEN-CLIENT-1.0.0`.

The built mod is in `build/libs/` and the GitHub artifact contains the remapped JAR.

## Install

1. Install Fabric Loader for Minecraft 1.21.11.
2. Install the matching Fabric API for 1.21.11.
3. Put `jorden-client-1.0.0.jar` in your `.minecraft/mods` folder.
4. Start the Fabric 1.21.11 profile.

## Controls

| Control | Action |
|---|---|
| Right Shift | Open JORDEN module menu |
| C (hold) | Zoom |
| Left Control (hold) | Toggle Sprint while moving |

## Notes

- Java 21 is required for Minecraft 1.21.11.
- CPS is an approximate client-side click counter.
- Configuration is saved to `.minecraft/config/jorden-client.properties`.
- GitHub Actions compiles the source; it does not upload the mod to Minecraft automatically.
