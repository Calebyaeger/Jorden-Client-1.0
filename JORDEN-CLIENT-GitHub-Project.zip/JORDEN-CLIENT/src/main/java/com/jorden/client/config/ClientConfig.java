package com.jorden.client.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ClientConfig {
    private static final Path FILE = Path.of("config", "jorden-client.properties");

    public static boolean hudEnabled = true;
    public static boolean fpsEnabled = true;
    public static boolean coordinatesEnabled = true;
    public static boolean keystrokesEnabled = true;
    public static boolean cpsEnabled = true;
    public static boolean armorEnabled = true;
    public static boolean crosshairEnabled = true;
    public static boolean toggleSprintEnabled = true;
    public static String theme = "LUNAR";

    private ClientConfig() {}

    public static void load() {
        Properties p = new Properties();
        if (Files.exists(FILE)) {
            try (InputStream in = Files.newInputStream(FILE)) {
                p.load(in);
                hudEnabled = Boolean.parseBoolean(p.getProperty("hud", "true"));
                fpsEnabled = Boolean.parseBoolean(p.getProperty("fps", "true"));
                coordinatesEnabled = Boolean.parseBoolean(p.getProperty("coordinates", "true"));
                keystrokesEnabled = Boolean.parseBoolean(p.getProperty("keystrokes", "true"));
                cpsEnabled = Boolean.parseBoolean(p.getProperty("cps", "true"));
                armorEnabled = Boolean.parseBoolean(p.getProperty("armor", "true"));
                crosshairEnabled = Boolean.parseBoolean(p.getProperty("crosshair", "true"));
                toggleSprintEnabled = Boolean.parseBoolean(p.getProperty("toggleSprint", "true"));
                theme = p.getProperty("theme", "LUNAR");
            } catch (IOException ignored) {
            }
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud", Boolean.toString(hudEnabled));
        p.setProperty("fps", Boolean.toString(fpsEnabled));
        p.setProperty("coordinates", Boolean.toString(coordinatesEnabled));
        p.setProperty("keystrokes", Boolean.toString(keystrokesEnabled));
        p.setProperty("cps", Boolean.toString(cpsEnabled));
        p.setProperty("armor", Boolean.toString(armorEnabled));
        p.setProperty("crosshair", Boolean.toString(crosshairEnabled));
        p.setProperty("toggleSprint", Boolean.toString(toggleSprintEnabled));
        p.setProperty("theme", theme);
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "JORDEN CLIENT settings");
            }
        } catch (IOException ignored) {
        }
    }
}
