package com.jorden.client;

import com.jorden.client.config.ClientConfig;
import com.jorden.client.gui.ClientMenuScreen;
import com.jorden.client.hud.ClientHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class JordenClient implements ClientModInitializer {
    public static final String MOD_ID = "jorden_client";
    public static KeyBinding MENU_KEY;
    public static KeyBinding ZOOM_KEY;
    public static KeyBinding SPRINT_KEY;

    @Override
    public void onInitializeClient() {
        ClientConfig.load();

        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.jorden_client.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.jorden_client.zoom", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C, KeyBinding.Category.MISC));
        SPRINT_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.jorden_client.sprint", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_CONTROL, KeyBinding.Category.MISC));

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> ClientHud.render(drawContext));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (MENU_KEY.wasPressed()) {
                client.setScreen(new ClientMenuScreen(client.currentScreen));
            }
            ClientHud.tick(client);
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                screen.addDrawableChild(ButtonWidget.builder(Text.literal("JORDEN CLIENT"), button ->
                        client.setScreen(new ClientMenuScreen(screen)))
                        .dimensions(scaledWidth / 2 - 100, scaledHeight - 28, 200, 20)
                        .build());
            }
        });
    }
}
