package com.jorden.client.mixin;

import com.jorden.client.hud.ClientHud;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void jorden$trackClicks(long window, int button, int action, int mods, CallbackInfo ci) {
        if (action == 1 && (button == 0 || button == 1)) {
            ClientHud.registerClick();
        }
    }
}
