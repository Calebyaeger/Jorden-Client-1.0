package com.jorden.client.gui;

import com.jorden.client.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ClientMenuScreen extends Screen {
    private final Screen parent;
    private int accent = 0xFF8AB4F8;

    public ClientMenuScreen(Screen parent) {
        super(Text.literal("JORDEN CLIENT"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = width / 2;
        int top = Math.max(42, height / 2 - 105);
        int w = 190;
        int h = 20;
        int gap = 24;

        addDrawableChild(toggle("HUD", () -> ClientConfig.hudEnabled,
                v -> ClientConfig.hudEnabled = v, center - w - 5, top, w, h));
        addDrawableChild(toggle("FPS Counter", () -> ClientConfig.fpsEnabled,
                v -> ClientConfig.fpsEnabled = v, center + 5, top, w, h));
        addDrawableChild(toggle("Coordinates", () -> ClientConfig.coordinatesEnabled,
                v -> ClientConfig.coordinatesEnabled = v, center - w - 5, top + gap, w, h));
        addDrawableChild(toggle("Keystrokes", () -> ClientConfig.keystrokesEnabled,
                v -> ClientConfig.keystrokesEnabled = v, center + 5, top + gap, w, h));
        addDrawableChild(toggle("CPS Counter", () -> ClientConfig.cpsEnabled,
                v -> ClientConfig.cpsEnabled = v, center - w - 5, top + gap * 2, w, h));
        addDrawableChild(toggle("Armor HUD", () -> ClientConfig.armorEnabled,
                v -> ClientConfig.armorEnabled = v, center + 5, top + gap * 2, w, h));
        addDrawableChild(toggle("Custom Crosshair", () -> ClientConfig.crosshairEnabled,
                v -> ClientConfig.crosshairEnabled = v, center - w - 5, top + gap * 3, w, h));
        addDrawableChild(toggle("Toggle Sprint", () -> ClientConfig.toggleSprintEnabled,
                v -> ClientConfig.toggleSprintEnabled = v, center + 5, top + gap * 3, w, h));

        addDrawableChild(ButtonWidget.builder(Text.literal("Theme: " + ClientConfig.theme), button -> {
            ClientConfig.theme = switch (ClientConfig.theme.toUpperCase()) {
                case "LUNAR" -> "PURPLE";
                case "PURPLE" -> "CYAN";
                case "CYAN" -> "RED";
                default -> "LUNAR";
            };
            button.setMessage(Text.literal("Theme: " + ClientConfig.theme));
            ClientConfig.save();
        }).dimensions(center - 95, top + gap * 4 + 5, 190, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Save Settings"), button -> {
            ClientConfig.save();
            button.setMessage(Text.literal("Saved!"));
        }).dimensions(center - 95, top + gap * 5 + 5, 190, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(center - 95, top + gap * 6 + 5, 190, 20).build());
    }

    private ButtonWidget toggle(String name, java.util.function.Supplier<Boolean> getter,
                                java.util.function.Consumer<Boolean> setter,
                                int x, int y, int w, int h) {
        return ButtonWidget.builder(label(name, getter.get()), button -> {
            boolean next = !getter.get();
            setter.accept(next);
            button.setMessage(label(name, next));
            ClientConfig.save();
        }).dimensions(x, y, w, h).build();
    }

    private Text label(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(0, 0, width, height, 0xA0101420);
        context.fill(width / 2 - 205, 24, width / 2 + 205, height - 24, 0xE0182032);
        context.fill(width / 2 - 205, 24, width / 2 + 205, 27, accent);
        context.drawCenteredTextWithShadow(textRenderer, "JORDEN CLIENT", width / 2, 35, accent);
        context.drawCenteredTextWithShadow(textRenderer, "LUNAR-INSPIRED CLIENT SETTINGS", width / 2, 48, 0xFFB8C7DF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
