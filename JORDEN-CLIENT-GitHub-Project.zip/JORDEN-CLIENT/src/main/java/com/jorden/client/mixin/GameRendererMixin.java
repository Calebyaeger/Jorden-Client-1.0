package com.jorden.client.mixin;

import com.jorden.client.hud.ClientHud;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void jorden$applyZoom(Camera camera, float tickDelta, boolean changingFov,
                                  CallbackInfoReturnable<Double> cir) {
        float zoom = ClientHud.getZoom();
        if (zoom > 1.0f) cir.setReturnValue(cir.getReturnValue() / zoom);
    }
}
