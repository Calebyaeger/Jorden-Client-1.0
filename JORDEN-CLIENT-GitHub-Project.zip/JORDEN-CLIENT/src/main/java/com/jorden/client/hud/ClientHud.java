package com.jorden.client.hud;

import com.jorden.client.JordenClient;
import com.jorden.client.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.Deque;

public final class ClientHud {
    private static final Deque<Long> CLICKS = new ArrayDeque<>();
    private static long lastClick;
    private static boolean sprintToggled;
    private static float zoom = 1.0f;

    private ClientHud() {}

    public static void registerClick() {
        long now = System.currentTimeMillis();
        CLICKS.addLast(now);
        lastClick = now;
        trimClicks(now);
    }

    private static void trimClicks(long now) {
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.removeFirst();
    }

    public static void tick(MinecraftClient client) {
        long now = System.currentTimeMillis();
        trimClicks(now);
        if (client.player == null) return;

        if (ClientConfig.toggleSprintEnabled && JordenClient.SPRINT_KEY.isPressed()
                && client.player.forwardSpeed > 0.0f) {
            sprintToggled = true;
        }
        if (client.player.forwardSpeed <= 0.0f || client.player.isSneaking()) {
            sprintToggled = false;
        }
        if (sprintToggled && client.player.forwardSpeed > 0.0f) {
            client.player.setSprinting(true);
        }

        zoom = JordenClient.ZOOM_KEY.isPressed() ? 2.5f : 1.0f;
    }

    public static float getZoom() { return zoom; }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || !ClientConfig.hudEnabled) return;

        int accent = accent();
        int x = 8;
        int y = 8;
        drawPanel(ctx, x, y, 116, 38, accent);
        ctx.drawText(mc.textRenderer, Text.literal("JORDEN CLIENT"), x + 7, y + 6, accent, false);
        if (ClientConfig.fpsEnabled) {
            ctx.drawText(mc.textRenderer, Text.literal("FPS  " + mc.getCurrentFps()), x + 7, y + 20, 0xFFFFFFFF, false);
        }

        int right = mc.getWindow().getScaledWidth() - 8;
        if (ClientConfig.coordinatesEnabled) {
            String coords = String.format("XYZ  %.1f / %.1f / %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
            drawRight(ctx, coords, right, 8, 0xFFFFFFFF);
        }

        if (ClientConfig.cpsEnabled) {
            drawRight(ctx, "CPS  " + CLICKS.size(), right, 20, 0xFFFFFFFF);
        }

        if (ClientConfig.keystrokesEnabled) drawKeystrokes(ctx, mc);
        if (ClientConfig.armorEnabled) drawArmor(ctx, mc);
        if (ClientConfig.crosshairEnabled) drawCrosshair(ctx, mc, accent);
    }

    private static void drawPanel(DrawContext ctx, int x, int y, int w, int h, int accent) {
        ctx.fill(x, y, x + w, y + h, 0xB0101420);
        ctx.fill(x, y, x + w, y + 2, accent);
    }

    private static void drawRight(DrawContext ctx, String value, int right, int y, int color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ctx.drawText(mc.textRenderer, value, right - mc.textRenderer.getWidth(value), y, color, true);
    }

    private static void drawKeystrokes(DrawContext ctx, MinecraftClient mc) {
        int x = 8, y = mc.getWindow().getScaledHeight() - 68;
        String[] keys = {"W", "A", "S", "D"};
        int[] offsets = {18, 0, 18, 36};
        int[] row = {0, 1, 1, 1};
        for (int i = 0; i < keys.length; i++) {
            int bx = x + offsets[i], by = y + row[i] * 18;
            boolean down = switch (keys[i]) {
                case "W" -> mc.options.forwardKey.isPressed();
                case "A" -> mc.options.leftKey.isPressed();
                case "S" -> mc.options.backKey.isPressed();
                default -> mc.options.rightKey.isPressed();
            };
            ctx.fill(bx, by, bx + 16, by + 16, down ? accent() : 0xB0101420);
            ctx.drawCenteredTextWithShadow(mc.textRenderer, keys[i], bx + 8, by + 4, 0xFFFFFFFF);
        }
    }

    private static void drawArmor(DrawContext ctx, MinecraftClient mc) {
        int x = mc.getWindow().getScaledWidth() / 2 - 72;
        int y = mc.getWindow().getScaledHeight() - 58;
        for (int i = 0; i < mc.player.getInventory().armor.size(); i++) {
            var stack = mc.player.getInventory().armor.get(3 - i);
            ctx.drawItem(stack, x + i * 18, y);
        }
    }

    private static void drawCrosshair(DrawContext ctx, MinecraftClient mc, int color) {
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        ctx.fill(cx - 5, cy, cx + 6, cy + 1, color);
        ctx.fill(cx, cy - 5, cx + 1, cy + 6, color);
    }

    private static int accent() {
        return switch (ClientConfig.theme.toUpperCase()) {
            case "PURPLE" -> 0xFFB58CFF;
            case "CYAN" -> 0xFF55DDF5;
            case "RED" -> 0xFFFF626C;
            default -> 0xFF8AB4F8;
        };
    }
}
