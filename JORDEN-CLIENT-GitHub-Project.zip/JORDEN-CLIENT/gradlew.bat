@echo off
echo Use GitHub Actions to build this project, or install Gradle 9.2.1 and run: gradle build
exit /b 1
